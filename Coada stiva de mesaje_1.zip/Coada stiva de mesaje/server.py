import socket
import threading
import sys

SERVER_ADDRESSES = [("127.0.0.1", 3333), ("127.0.0.1", 3334), ("127.0.0.1", 3335)]
active_connections = {}

class ClientList:
    def __init__(self):
        self.clients = []
        self.lock = threading.Lock()

    def add_client(self, client, addr):
        with self.lock:
            if len(self.clients) < 4:  
                self.clients.append((client, addr))
                return True
            else:
                return False

    def remove_client(self, client):
        with self.lock:
            self.clients = [c for c in self.clients if c[0] != client]

    def notify_all(self, message, sender=None):
        with self.lock:
            for client, addr in self.clients:
                if client != sender:
                    try:
                        client.sendall(message.encode())
                        print(f"Message was sent from {addr}: {message}")
                    except Exception as e:
                        print(f"Failed to send message to {addr}: {e}")
                        self.clients.remove((client, addr))
                        client.close()

clients = ClientList()
is_running = True

class SubscriptionManager:
    def __init__(self):
        self.subscriptions = {}
        self.lock = threading.Lock()

    def notify_subscribers(self, key, message):
        with self.lock:
            if key in self.subscriptions:
                clients = self.subscriptions[key]
                for client in list(clients): 
                    try:
                        client.sendall(message.encode())
                        print(f"Notified {client.getpeername()} with message: {message}")
                    except:
                        self.unsubscribe(key, client, None)

    def notify_server(self, message, server_connection):
        if server_connection:
            try:
                server_connection.sendall(message.encode())
                print(f"Server notified with message: {message}")
            except Exception as e:
                print(f"Failed to notify server: {e}")
    
    def subscribe(self, key, client_socket, server_connection):
         with self.lock:
            if key not in self.subscriptions:
                self.subscriptions[key] = set()
            self.subscriptions[key].add(client_socket)
            message = f"{client_socket.getpeername()} subscribed to {key}"
            self.notify_subscribers(key, message)
            self.notify_server(message, server_connection)
                
    
    def unsubscribe(self, key, client_socket, server_connection):
        with self.lock:
            if key in self.subscriptions and client_socket in self.subscriptions[key]:
                self.subscriptions[key].remove(client_socket)
                if not self.subscriptions[key]:
                    del self.subscriptions[key]
                message = f"{client_socket.getpeername()} unsubscribed from {key}"
                self.notify_subscribers(key, message)
                self.notify_server(message, server_connection)
   
subscriptions = SubscriptionManager()

def connect_to_server(server_addresses):
    for server in server_addresses:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect(server)
            response = s.recv(1024).decode()
            if response == 'server_full':
                print(f"Server {server} is full. Trying next server...")
                s.close()
                continue
            print(f"Connected to server {server}")
            return s
        except Exception as e:
            print(f"Failed to connect to server {server}: {e}")
    return None

def accept_connections(server_socket, server_connection):
    server_socket.settimeout(1.0)
    while is_running:
        try:
            client_socket, addr = server_socket.accept()
            if clients.add_client(client_socket, addr):
                threading.Thread(target=handle_client, args=(client_socket, addr, server_connection)).start()
            else:
                client_socket.sendall(b'server_full')
                client_socket.close()
        except socket.timeout:
            continue
        except OSError as e:
            print(f"Error accepting connections: {e}")
            break

def execute_command(key, argument, client_socket):
    if key == "log":
        log_message(argument)
    elif key == "add":
        result = add_numbers(argument)
        response = f"Result of addition: {result}"
        client_socket.sendall(response.encode())
    else:
        error_msg = "Unknown command."
        client_socket.sendall(error_msg.encode())

def log_message(message):
    print(f"Log: {message}")

def add_numbers(argument):
    try:
        numbers = [int(num) for num in argument.split()]
        return sum(numbers)
    except Exception as e:
        print(f"Error processing addition: {e}")
        return None

def process_command(client_socket, data, addr, server_connection):
    try:
        command, key = data.split(maxsplit=1)
        if command == "subscribe":
            subscriptions.subscribe(key, client_socket, server_connection)
        elif command == "unsubscribe":
            subscriptions.unsubscribe(key, client_socket, server_connection)
        elif command == "process":
            execute_command(key, data[len(command) + len(key) + 1:], client_socket)
        else:
            subscriptions.notify_subscribers(key, data)
            subscriptions.notify_server(data, server_connection)
    except ValueError:
        print(f"Invalid command format from {addr}: {data}")

def handle_client(client_socket, addr, server_connection):
    active_connections[addr] = client_socket
    try:
        print(f"\nClient {addr} connected.")
        connection_message = f"New client connected: {addr} has joined the server."

        clients.notify_all(connection_message, sender=client_socket)
        
        if server_connection:
            server_notification = f"New client {addr} connected to the network."
            server_connection.sendall(server_notification.encode())

        client_socket.sendall(f"You are now connected to the server at {addr}".encode())

        while True:
            data = client_socket.recv(1024).decode()
            if not data:
                break
            if data.startswith('port_listening'):
                print(data)
            if data == 'client_disconnected':
                clients.remove_client(client_socket)
                clients.notify_all(f"{addr} has disconnected from the server")
                print(f"{addr} has disconnected from the server")
                break
            process_command(client_socket, data, addr, server_connection)
    except Exception as e:
        print(f"Error handling client: {e}")
    finally:
        client_socket.close()
        del active_connections[addr]
        for key in list(subscriptions.subscriptions.keys()):
            subscriptions.unsubscribe(key, client_socket, server_connection)


def main(port):
    global is_running
    server_socket = None 
    server_connection = None 
    accept_thread = None
    try:
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind(("127.0.0.1", port))
        server_socket.listen()
        print(f"Server listening on port {port}")

        if port not in [3333, 3334, 3335]:
            p_connection = input("Connect to server(0 for default): ")
            if p_connection == '0':
                server_connection = connect_to_server(SERVER_ADDRESSES)
            else:
                server_connection = connect_to_server([("127.0.0.1", int(p_connection))])

        accept_thread = threading.Thread(target=accept_connections, args=(server_socket, server_connection))
        accept_thread.start()
            
        while True:
            message0 = input("Send the message to: (0 - server, 1 - clients, 2 -  subscribe, 3 - unsubscribe or exit): ")
            if message0 == '0':
                line = input('>Enter message to send to server: ')
                if server_connection:
                    server_connection.send(line.encode())
            elif message0 == '1':
                message = input("\nEnter message to send to clients: ")
                clients.notify_all(f"\nMessage from server: {message}")
            elif message0 == '2':
                addr_input = input("Enter address of client to subscribe (format IP:port): ")
                try:
                    ip, port = addr_input.split(':')
                    addr = (ip, int(port))  
                    if addr in active_connections:
                        client_socket = active_connections[addr]
                        key = input("Enter key to subscribe to: ")
                        subscriptions.subscribe(key, client_socket, server_connection)
                    else:
                        print("No active connection found for this address.")
                except ValueError:
                    print("Invalid address format. Please use the format IP:port.")

            elif message0 == '3':
                addr_input = input("Enter address of client to unsubscribe (format IP:port): ")
                try:
                    ip, port = addr_input.split(':')
                    addr = (ip, int(port))  
                    if addr in active_connections:
                        client_socket = active_connections[addr]
                        key = input("Enter key to unsubscribe from: ")
                        subscriptions.unsubscribe(key, client_socket, server_connection)
                    else:
                        print("No active connection found for this address.")
                except ValueError:
                    print("Invalid address format. Please use the format IP:port.")
            elif message0 == 'exit':
                clients.notify_all('\nServer is shutting down')
                is_running = False
                try:
                    server_connection.send(b"client_disconnected")
                except:
                    pass
                break
    except BaseException as err:
        print(f"Error: {err}")
    finally:
        if server_socket:
            server_socket.close()
        if accept_thread and accept_thread.is_alive():
            accept_thread.join()
  
if __name__ == '__main__':
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <port>")
        sys.exit(1)
    main(int(sys.argv[1]))